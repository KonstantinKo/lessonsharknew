<?php
	class AppError extends ErrorHandler
	{
		
	}
?>